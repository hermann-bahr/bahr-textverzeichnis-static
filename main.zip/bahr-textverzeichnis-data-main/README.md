# HermannBahr-Textverzeichnis

Das Textverzeichnis mit allen in Druck erschienenen Texten Hermann Bahrs (1863–1934) erschien 2014 im VDG-Verlag in Weimar: https://asw-verlage.de/katalog/hermann_bahr_____textverzeichnis-801.html (ISBN 978-3-89739-800-9) 

Ich versuche nun, die digital vorliegenden Daten auf eine eigene Website zu bekommen, da 1) der damals verwendete Arbeitsablauf längst im digitalen Orkus gelandet ist und 2) ich technisch seither einiges dazugelernt habe. (Danke Regex!)

Die Datei textverzeichnis.xml enthält alle Texte als biblStruct, sowie die indizierten Personen als listRef, die auf die Datei listperson.xml verweist. Alles andere dann, wenn mir klar wird, wie ich weiter verfahre.

